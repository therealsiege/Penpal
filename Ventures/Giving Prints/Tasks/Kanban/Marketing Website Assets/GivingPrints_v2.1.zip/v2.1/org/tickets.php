<?PHP
define("ZDAPIKEY", "gScfwK4oX1oj5QpiFT4kiBLoKRmAWSlhDmgnUvhD");
define("ZDUSER", "anthonyladd@givingprints.com");
define("ZDURL", "https://givingprints.zendesk.com/api/v2");

/* Note: do not put a trailing slash at the end of v2 */

function curlWrap($url, $json, $action)
{
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_MAXREDIRS, 10 );
	curl_setopt($ch, CURLOPT_URL, ZDURL.$url);
	curl_setopt($ch, CURLOPT_USERPWD, ZDUSER."/token:".ZDAPIKEY);
	switch($action){
		case "POST":
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
			curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
			break;
		case "GET":
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
			break;
		case "PUT":
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
			curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
		default:
			break;
	}
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
	curl_setopt($ch, CURLOPT_USERAGENT, "MozillaXYZ/1.0");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_TIMEOUT, 10);
	$output = curl_exec($ch);
	curl_close($ch);
	$decoded = json_decode($output);
	return $decoded;
}

foreach($_POST as $key => $value){
	if(preg_match('/^z_/i',$key)){
		$arr[strip_tags($key)] = strip_tags($value);
	}
}


$create = json_encode(
	array(
	'ticket' => array(
		'subject' => "GivingPrints - " . $arr['z_formname'], 
		'description' => $arr['z_description'], 
		'requester' => array(
			'name' => $arr['z_name'], 
			'email' => $arr['z_requester']
			), 
		'custom_fields' => array(
			array(
				'id' => 22217309, 
				'value' => $arr['z_22217309']
				),
			array(
				'id' => 22253765, 
				'value' => $arr['z_22253765']
				)
		)
	),
	JSON_FORCE_OBJECT
	)
);




 







$data = curlWrap("/tickets.json", $create, "POST");
var_dump($data);

header( "Location: http://givingprints.com/index.html" );
exit;
?>